console.log(require('colors').red('Starting Chaotic IO...'));if(code=require('./src/Main').Main.main(process.argv))console.error(code),process.exit(code)
